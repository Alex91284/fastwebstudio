export default function AdminPanel() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-blue-600">Panel de Administración</h1>
    </div>
  );
}
