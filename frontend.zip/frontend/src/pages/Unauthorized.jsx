export default function Unauthorized() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-3xl font-bold text-red-600">🚫 Acceso Denegado</h1>
      <p>No tienes permiso para ver esta página.</p>
    </div>
  );
}
